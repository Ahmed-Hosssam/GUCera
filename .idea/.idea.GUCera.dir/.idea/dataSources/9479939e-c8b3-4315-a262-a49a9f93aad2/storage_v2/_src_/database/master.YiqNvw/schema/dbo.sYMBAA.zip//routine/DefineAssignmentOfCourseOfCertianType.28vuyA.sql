-- Choose a course to define assignments of different types 
create proc DefineAssignmentOfCourseOfCertianType @instId int,
                                                  @cid int,
                                                  @number int,
                                                  @type varchar(10),
                                                  @fullGrade int,
                                                  @weight decimal(4, 1),
                                                  @deadline datetime,
                                                  @content varchar(200)
as
    if exists(select *
              from InstructorTeachCourse
              where instId = @instId
                and cid = @cid
        )
        begin
            insert into Assignment values (@cid, @number, @type, @fullGrade, @weight, @deadline, @content)
        end
go

