/*student add credit card details.*/
create proc addCreditCard @sid int, @number varchar(15), @cardHolderName varchar(16), @expiryDate datetime,
                          @cvv varchar(3)
as
Insert Into CreditCard(number, cardHolderName, expiryDate, cvv)
values (@number, @cardHolderName, @expiryDate, @cvv);

Insert Into StudentAddCreditCard(sid, creditCardNumber)
values (@sid, @number);
go

