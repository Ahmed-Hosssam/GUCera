create proc show @id int
as
SELECT *
from Employee
where id = @id
go

