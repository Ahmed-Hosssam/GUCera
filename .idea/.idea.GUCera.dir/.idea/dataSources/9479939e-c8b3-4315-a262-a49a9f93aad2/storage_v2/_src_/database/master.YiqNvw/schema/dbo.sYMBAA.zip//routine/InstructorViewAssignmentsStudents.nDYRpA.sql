create proc InstructorViewAssignmentsStudents @instrId int, @cid int
as
    IF EXISTS(
            select *
            from InstructorTeachCourse
            where instId = @instrId
              and cid = @cid
        )
        BEGIN
            SELECT *
            from StudentTakeAssignment
            where cid = @cid;
        END
go

