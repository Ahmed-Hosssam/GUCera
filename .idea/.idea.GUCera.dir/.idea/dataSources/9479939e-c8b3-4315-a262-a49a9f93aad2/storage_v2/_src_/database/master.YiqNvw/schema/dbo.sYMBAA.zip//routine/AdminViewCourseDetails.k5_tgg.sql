-- View any course details such as course description and content.
create proc AdminViewCourseDetails @courseId int
as
select *
from Course
where id = @courseId
go

