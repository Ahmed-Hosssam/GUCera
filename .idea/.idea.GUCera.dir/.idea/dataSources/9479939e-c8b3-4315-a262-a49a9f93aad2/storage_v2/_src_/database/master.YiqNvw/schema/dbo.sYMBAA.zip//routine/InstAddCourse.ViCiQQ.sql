create proc InstAddCourse @creditHours int,
                          @name varchar(10),
                          @price DECIMAL(6, 2),
                          @instructorId int
as
insert into Course (creditHours, name, price, instructorId)
values (@creditHours, @name, @price, @instructorId)
go

