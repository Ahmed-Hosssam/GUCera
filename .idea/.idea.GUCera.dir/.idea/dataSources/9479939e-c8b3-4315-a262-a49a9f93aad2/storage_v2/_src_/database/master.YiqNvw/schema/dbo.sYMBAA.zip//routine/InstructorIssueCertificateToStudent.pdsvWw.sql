create proc InstructorIssueCertificateToStudent @cid int, @sid int, @insId int, @issueDate datetime
as
    IF EXISTS(
            SELECT *
            from InstructorTeachCourse
            where instId = @insId
              and cid = @cid
        )
        Begin
            declare @grade decimal(10, 2);
            select @grade = grade
            from StudentTakeCourse
            where sid = @sid
              and cid = @cid;
            if (@grade > 50)
                insert into StudentCertifyCourse (sid, cid, issueDate) values (@sid, @cid, @issueDate);
        end
go

