/*3 - h List all students in the system */
create proc AdminListAllStudents
as
select *
from Student
go

