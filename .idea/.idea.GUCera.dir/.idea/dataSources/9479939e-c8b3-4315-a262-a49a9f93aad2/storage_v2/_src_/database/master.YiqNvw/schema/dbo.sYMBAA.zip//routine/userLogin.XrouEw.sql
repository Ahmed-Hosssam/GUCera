-- login
create proc userLogin @ID int, @password varchar(20),
                      @success bit output
as
select @success = count(*)
from Users u
where u.id = @ID
  and u.password = @password
go

