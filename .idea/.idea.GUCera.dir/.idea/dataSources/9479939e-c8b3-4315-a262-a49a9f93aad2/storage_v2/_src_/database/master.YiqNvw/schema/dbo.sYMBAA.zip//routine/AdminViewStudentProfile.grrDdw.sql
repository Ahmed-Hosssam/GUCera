create proc AdminViewStudentProfile @sid int
as
select *
from Student
         inner join Users on Student.id = Users.id
where @sid = Student.id
  and Student.id is not null
  and Student.gpa is not null
  and Users.firstName is not null
  and Users.lastName is not null
  and Users.password is not null
  and Users.address is not null
  and Users.gender is not null
go

