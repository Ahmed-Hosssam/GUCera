create procedure rateInstructor @rate DECIMAL(2, 1), @sid INT, @insid INT
as
insert into StudentRateInstructor (sid, instId, rate)
values (@sid, @insid, @rate)
go

