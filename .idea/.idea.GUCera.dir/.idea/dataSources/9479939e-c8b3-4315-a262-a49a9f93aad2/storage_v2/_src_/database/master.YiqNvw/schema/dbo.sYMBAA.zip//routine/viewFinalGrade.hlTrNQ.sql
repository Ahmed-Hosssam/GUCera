create procedure viewFinalGrade @cid INT, @sid INT, @finalgrade decimal(10, 2) output
as
select @finalgrade = sum((grade / fullGrade) * weight)
from StudentTakeAssignment
         inner join Assignment on StudentTakeAssignment.cid = Assignment.cid and
                                  StudentTakeAssignment.assignmentType = Assignment.type and
                                  StudentTakeAssignment.assignmentNumber = Assignment.number
where @cid = StudentTakeAssignment.cid
  and @sid = StudentTakeAssignment.sid
go

