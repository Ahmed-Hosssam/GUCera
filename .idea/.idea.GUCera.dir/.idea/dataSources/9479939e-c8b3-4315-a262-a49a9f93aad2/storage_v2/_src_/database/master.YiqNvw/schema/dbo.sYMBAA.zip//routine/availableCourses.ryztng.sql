/*List all courses in the system accepted by the admin so the student can choose one to enroll*/
create proc availableCourses
as
SELECT name
from Course
WHERE accepted=1;
go

