/*Edit the profile of a student (change any of their personal information).*/
create proc editMyProfile @id int, @firstName varchar(10), @lastName varChar(10),
                          @password varchar(10), @gender binary, @email varchar(10), @address varchar(10)
as
UPDATE Users
SET firstName=@firstName,
    lastName=@lastName,
    password=@password,
    gender=@gender,
    email=@email,
    address=@address
where id = @id;
go

