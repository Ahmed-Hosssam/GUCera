-- List all instructors in the system.
create proc AdminListInstr
as
select u.firstName, u.lastName
from Instructor i
         inner join Users u on i.id = u.id
go

