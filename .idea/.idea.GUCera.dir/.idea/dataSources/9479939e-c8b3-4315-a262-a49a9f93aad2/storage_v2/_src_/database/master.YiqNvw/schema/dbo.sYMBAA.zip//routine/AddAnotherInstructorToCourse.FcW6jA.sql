create proc AddAnotherInstructorToCourse @insid int,
                                         @cid int,
                                         @adderIns int
as
insert into InstructorTeachCourse
values (@insId, @cid)
go

