create procedure addFeedback @comment VARCHAR(100), @cid INT, @sid INT
as
insert into Feedback (comments, cid, sid)
values (@comment, @cid, @sid)
go

