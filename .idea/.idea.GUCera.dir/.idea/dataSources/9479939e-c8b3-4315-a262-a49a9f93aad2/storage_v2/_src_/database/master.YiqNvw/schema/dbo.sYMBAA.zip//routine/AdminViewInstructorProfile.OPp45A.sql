-- view the profile of any instructor that contains all his/her information.
create proc AdminViewInstructorProfile @instrId int
as
select u.firstName, u.lastName, u.address, u.email, u.gender
from Instructor i
         inner join Users u on i.id = u.id
where u.id = @instrId
go

