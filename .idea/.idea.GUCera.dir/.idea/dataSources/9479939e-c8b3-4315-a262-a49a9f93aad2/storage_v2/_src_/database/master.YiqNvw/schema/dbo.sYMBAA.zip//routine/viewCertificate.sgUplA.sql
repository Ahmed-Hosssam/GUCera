create procedure viewCertificate @cid INT, @sid INT
as
select *
from StudentCertifyCourse
where sid = @sid
  and cid = @cid
go

