create procedure submitAssign @assignType VARCHAR(10), @assignnumber int, @sid INT, @cid INT
as
insert into StudentTakeAssignment (sid, cid, assignmentNumber, assignmentType)
values (@sid, @cid, @assignnumber, @assignType)
go

