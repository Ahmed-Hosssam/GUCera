create proc ViewFeedbacksAddedByStudentsOnMyCourse @instrId int, @cid int
as
SELECT *
from Feedback F
         INNER JOIN Course C on C.id = F.cid
         Inner Join Instructor I on I.id = C.instructorId
where C.id = @cid
  and I.id = @instrId
go

