create proc enrollInCourse @sid int, @cid int, @instr int
as
declare @count int, @taken int;
Select @count = count(*)
from CoursePrerequisiteCourse
where cid = @cid;

SELECT @taken = count(*)
from CoursePrerequisiteCourse CPC
         INNER JOIN StudentCertifyCourse SCC on CPC.prerequisiteId = SCC.cid
where CPC.cid = @cid
  and SCC.sid = @sid;
    IF (@taken = @count)
        Begin
            insert into StudentTakeCourse(sid, cid, instId) values (@sid, @cid, @instr);
        End;
go

