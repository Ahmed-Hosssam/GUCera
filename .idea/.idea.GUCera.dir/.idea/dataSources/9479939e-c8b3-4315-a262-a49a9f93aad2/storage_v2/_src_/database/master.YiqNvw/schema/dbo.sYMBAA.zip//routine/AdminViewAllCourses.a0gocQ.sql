-- List all courses in the system.
create proc AdminViewAllCourses
as
select *
from Course
go

