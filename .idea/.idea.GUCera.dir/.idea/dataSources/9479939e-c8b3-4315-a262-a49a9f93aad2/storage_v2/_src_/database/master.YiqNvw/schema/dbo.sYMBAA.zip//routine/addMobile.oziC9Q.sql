-- add my telephone number(s)
create proc addMobile @ID int, @mobile_number varchar(20)
as
insert into UserMobileNumber (id, mobileNumber)
values (@ID, @mobile_number)
go

