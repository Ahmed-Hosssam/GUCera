/* Issue the promo code created to any student. */
create proc AdminIssuePromocodeToStudent @sid int,
                                         @pid varchar(6)
as
insert into StudentHasPromocode
values (@sid, @pid)
go

