-- specify the course pre-requisites. 
create proc DefineCoursePrerequisites @cid int,
                                      @prerequsiteId int
as
insert into CoursePrerequisiteCourse
values (@cid, @prerequsiteId)
go

