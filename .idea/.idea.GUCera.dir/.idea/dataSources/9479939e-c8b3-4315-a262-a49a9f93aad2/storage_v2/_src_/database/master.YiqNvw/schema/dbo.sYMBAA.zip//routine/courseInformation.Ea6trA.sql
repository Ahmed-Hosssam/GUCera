create proc courseInformation @id int
as
SELECT *
from Course
where id = @id
go

