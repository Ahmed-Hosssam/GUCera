create procedure viewPromocode @sid int
as
select Promocode.code, issueDate, expiryDate, discountamount, adminId
from Promocode
         inner join StudentHasPromocode on Promocode.code = StudentHasPromocode.code
where StudentHasPromocode.sid = @sid
go

