/* Choose any of my course to edit its description or content  */
create proc UpdateCourseContent @instrId int,
                                @courseId int,
                                @content varchar(20)
as
update Course
set Course.courseDescription = content
where Course.id = @courseId
  and EXISTS(
        select *
        from InstructorTeachCourse IT
        where IT.instId = @instrId
          and IT.cid = @courseId
    )
go

