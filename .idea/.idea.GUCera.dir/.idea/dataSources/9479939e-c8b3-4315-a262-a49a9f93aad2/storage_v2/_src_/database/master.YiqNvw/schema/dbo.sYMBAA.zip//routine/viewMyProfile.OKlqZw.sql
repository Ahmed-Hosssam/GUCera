create proc viewMyProfile @id int
as
SELECT *
from Student S
         Inner Join Users U on U.id = S.id
         Inner Join UserMobileNumber UMN on U.id = UMN.id
where s.id = @id;
go

