-- Create new Promo codes by inserting all promo code details.
create proc AdminCreatePromocode @code varchar(6), @isuueDate datetime, @expiryDate datetime, @discount decimal(4, 2),
                                 @adminId int
as
insert into Promocode (code, issueDate, expiryDate, discountamount, adminId)
values (@code, @isuueDate, @expiryDate, @discount, @adminId)
go

