create proc AdminAcceptRejectCourse @adminId int, @courseId int
as
update Course
set adminId  = @adminId,
    accepted = 1
where id = @courseId
go

