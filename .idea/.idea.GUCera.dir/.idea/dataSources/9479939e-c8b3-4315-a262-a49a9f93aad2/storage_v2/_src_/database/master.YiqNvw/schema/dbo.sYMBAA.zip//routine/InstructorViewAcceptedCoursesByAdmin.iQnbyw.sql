-- View my courses that were accepted by the admin 
create proc InstructorViewAcceptedCoursesByAdmin @instrId int
as
select Course.id
from Course
         inner join InstructorTeachCourse on Course.id = InstructorTeachCourse.cid
where instId = @instrId
  and Course.accepted = 1
go

