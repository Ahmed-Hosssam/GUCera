create procedure payCourse @cid INT, @sid INT
as
insert into StudentTakeCourse (sid, cid, payedfor)
values (@sid, @cid, 1)
go

