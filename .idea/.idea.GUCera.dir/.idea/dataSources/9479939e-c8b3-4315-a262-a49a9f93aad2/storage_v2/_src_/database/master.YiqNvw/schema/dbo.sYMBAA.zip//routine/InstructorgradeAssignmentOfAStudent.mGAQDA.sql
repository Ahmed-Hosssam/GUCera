create proc InstructorgradeAssignmentOfAStudent @instrID int, @sid int, @cid int, @assignmentNumber int,
                                                @type varchar(10),
                                                @grade decimal(5, 2)
as
    IF EXISTS(
            select *
            from InstructorTeachCourse
            where instId = @instrId
              and cid = @cid
        )
        BEGIN
            INSERT INTO StudentTakeAssignment(sid, cid, assignmentNumber, assignmentType, grade)
            values (@sid, @cid, @assignmentNumber, @type, @grade);
        end
go

