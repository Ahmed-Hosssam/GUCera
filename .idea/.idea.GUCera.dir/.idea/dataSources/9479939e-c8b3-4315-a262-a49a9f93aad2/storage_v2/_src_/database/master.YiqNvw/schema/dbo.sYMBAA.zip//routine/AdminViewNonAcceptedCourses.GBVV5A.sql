-- List all the courses added by instructors not yet accepted.
create proc AdminViewNonAcceptedCourses
as
select *
from Course
where accepted = 0
go

