create procedure viewAssign @courseId int, @Sid int
as
select Assignment.cid, number, type, fullGrade, weight, deadline, content
from Assignment
         inner join StudentTakeAssignment on Assignment.cid = StudentTakeAssignment.cid
where @Sid = StudentTakeAssignment.sid
go

