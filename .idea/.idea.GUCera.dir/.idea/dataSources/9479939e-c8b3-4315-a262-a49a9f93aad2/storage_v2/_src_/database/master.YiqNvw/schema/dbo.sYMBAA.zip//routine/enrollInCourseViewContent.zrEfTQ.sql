create procedure enrollInCourseViewContent @id int, @cid int
as
select id, creditHours, name, courseDescription, price, content
from Course
         inner join StudentTakeCourse on Course.id = StudentTakeCourse.cid
where StudentTakeCourse.sid = @id
  and Course.id = @cid
go

