/*issue certificate to a student upon course completion if his final grade >50*/
create proc calculateFinalGrade @cid int, @sid int, @insId int
as
    IF EXISTS(
            SELECT *
            from InstructorTeachCourse
            where instId = @insId
              and cid = @cid
        )
        Begin
            Declare @grade decimal(5,2);
            SELECT @grade = sum(STA.grade * A.weight)
            FROM Assignment A
                     inner join StudentTakeAssignment STA
                                on A.cid = STA.cid and A.number = STA.assignmentNumber and A.type = STA.assignmentType
            where A.cid = @cid
              and STA.sid = @sid;
            declare @sum int;
            SELECT @sum = sum(weight)
            FROM Assignment A
                     inner join StudentTakeAssignment STA
                                on A.cid = STA.cid and A.number = STA.assignmentNumber and A.type = STA.assignmentType
            UPDATE StudentTakeAssignment
            set grade=@grade/@sum
            where sid = @sid;
        END;
go

