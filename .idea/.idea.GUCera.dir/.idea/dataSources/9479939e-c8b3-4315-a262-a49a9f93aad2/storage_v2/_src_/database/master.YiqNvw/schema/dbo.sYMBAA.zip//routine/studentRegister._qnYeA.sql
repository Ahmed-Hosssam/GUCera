create proc studentRegister @first_name varchar(20), @last_name varchar(20), @password varchar(20), @email varchar(50),
                            @gender bit, @address varchar(10)
as
insert into Users (firstName, lastName, password, gender, address)
values (@first_name, @last_name, @password, @gender, @address)
go

