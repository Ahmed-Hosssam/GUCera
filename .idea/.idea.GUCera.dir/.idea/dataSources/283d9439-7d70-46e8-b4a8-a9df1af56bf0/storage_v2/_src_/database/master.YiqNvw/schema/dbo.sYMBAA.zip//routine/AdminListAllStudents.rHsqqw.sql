create  proc AdminListAllStudents
as 
select  *
from Student
go

